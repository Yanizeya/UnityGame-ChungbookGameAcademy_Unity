﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Move : MonoBehaviour
{

    Rigidbody this_rigid;
    // Start is called before the first frame update
    void Start()
    {
        this_rigid = GetComponent<Rigidbody>();
        this_rigid.velocity = Vector3.down * 1000 * Time.deltaTime;
    }

    // Update is called once per frame
    void Update()
    {
        


    }

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log(other.gameObject.transform.Find("A").GetComponent<Text>().text);
    }

}
